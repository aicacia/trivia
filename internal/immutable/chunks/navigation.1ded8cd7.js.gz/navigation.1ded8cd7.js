import{j as o}from"./singletons.38b5dd91.js";const e=o("goto");export{e as g};
