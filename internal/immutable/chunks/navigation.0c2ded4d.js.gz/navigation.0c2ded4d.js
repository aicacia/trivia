import{j as o}from"./singletons.41d9df85.js";const e=o("goto");export{e as g};
